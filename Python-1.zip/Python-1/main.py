import discord

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True  # нужно для работы с каналами и ролями

client = discord.Client(intents=intents)

RULES = [
    "1️⃣ Будьте вежливы и уважайте других участников.",
    "2️⃣ Не спамьте в чатах.",
    "3️⃣ Запрещены оскорбления и токсичное поведение.",
    "4️⃣ Не рекламируйте сторонние ресурсы без разрешения.",
    "5️⃣ Соблюдайте правила Discord."
]

ROLE = [
    "1️⃣ Московские",
    "2️⃣ Подольские Замы",
    "3️⃣ Подмосковная лимита",
    "4️⃣ Работяги",
]

@client.event
async def on_ready():
    print(client.user)

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    # hello
    if message.content == "$hello":
        await message.channel.send("Hello!")
        await message.channel.send("Привет!")

    # правила
    elif message.content == "$rule":
        await message.channel.send("\n".join(RULES))

    # информация о ролях (старый вариант)
    elif message.content == "$roles":
        await message.channel.send("\n".join(ROLE))

    # доступы роли к каналам
    elif message.content.startswith("$role "):
        role_name = message.content[6:]  # после "$role "
        guild = message.guild

        role = discord.utils.get(guild.roles, name=role_name)

        if role is None:
            await message.channel.send("❌ Такая роль не найдена.")
            return

        доступные_каналы = []

        for channel in guild.channels:
            perms = channel.permissions_for(role)
            if perms.view_channel:
                доступные_каналы.append(f"• {channel.name}")

        if not доступные_каналы:
            await message.channel.send(
                f"🔒 У роли **{role.name}** нет доступа ни к одному каналу."
            )
            return

        await message.channel.send(
            f"📌 **Каналы, доступные для роли `{role.name}`:**\n"
            + "\n".join(доступные_каналы)
        )

client.run('MTQ1MjM0NzMxOTIyMjUzNDE4OA.GyMTZA.guqL9wOVbDHxDU5_lysAD_4qQXONZ3XCU5WbtA')
